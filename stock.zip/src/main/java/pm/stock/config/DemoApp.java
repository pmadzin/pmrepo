package pm.stock.config;

import java.math.BigDecimal;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import pm.stock.domian.GBCEStock;
import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;
import pm.stock.service.CalculationService;
import pm.stock.service.CalculationServiceImpl;
import pm.stock.service.MockStockConnectorService;
import pm.stock.service.MockTradeConnectorService;
import pm.stock.service.MockTradeStorageManager;
import pm.stock.service.StockConnectorService;
import pm.stock.service.TradeConnectorService;
import pm.stock.service.TradeStorageManager;

public class DemoApp {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DemoApp.class);
	
	
	MockTradeConnectorService tradeConnection = new MockTradeConnectorService();

	
	MockStockConnectorService stockConnectorService = new MockStockConnectorService();
	
	 
	MockTradeStorageManager storageManager= new MockTradeStorageManager();
	
	
	CalculationServiceImpl calculationService = new CalculationServiceImpl();
	
	public void startDemo() {
		while (true) {
			LOGGER.info("........Start new demo sequence.....................");
			
			
			for (String symbol : stockConnectorService.getStockSymbols()) {
				Collection<Trade> trades = tradeConnection.getTradesAfter(symbol,org.joda.time.LocalDateTime.now());
				storageManager.saveTrades(trades);
			}
			
			
			
			for (GBCEStock stock : stockConnectorService.getStocks()) {
				BigDecimal stockPrice = calculationService.calculateStockPrice(storageManager.getStoredTrades(), 2,stock);
				LOGGER.info("Stock {} Price is {} - based on last 2 minutes trades",stock,stockPrice);
				if (stockPrice!=null ) {
					BigDecimal dyeld = calculationService.calculateDividentYield(stockPrice, stock);					
					BigDecimal peoratio = calculationService.calculatePERatio(stockPrice, stock.getLastDivident());
					BigDecimal geo= calculationService.calculateGeometricMean(storageManager.getStoredTrades(), TradeType.ALL, stock);
					LOGGER.info("Stock {} - Dividend Yield ={} , PE Ratio = {}, Geometric Mean = {}",stock,dyeld,peoratio,geo);
				}
			}
			
			
			
			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				LOGGER.info("InterruptedException do nothing");
			}
			
		}
	}

	public TradeConnectorService getTradeConnection() {
		return tradeConnection;
	}

	

	public StockConnectorService getStockConnectorService() {
		return stockConnectorService;
	}

	
	public TradeStorageManager getStorageManager() {
		return storageManager;
	}

	
	public CalculationService getCalculationService() {
		return calculationService;
	}

	

	public static Logger getLogger() {
		return LOGGER;
	}
	
	

}
