package pm.stock.config;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;

@SpringBootApplication
public class StockServerApp {

	private static final Logger LOGGER = LoggerFactory.getLogger(StockServerApp.class);

	public static void main(String[] args) throws InterruptedException {
		String appName = "StockServerApp";
		String env = "dev";

		LOGGER.info(String.format("Starting %s in %s with args: %s", appName, env, Arrays.toString(args)));

		Predicate<String> isParameter = new Predicate<String>() {
			@Override
			public boolean apply(String input) {
				return input.startsWith("--");
			}
		};
		List<String> argsList = Arrays.asList(args);
		Collection<String> parameters = Collections2.filter(argsList, isParameter);
		Collection<String> configurations = Collections2.filter(argsList, Predicates.not(isParameter));

		SpringApplication springApplication = new SpringApplication(
				Lists.asList(StockServerApp.class, configurations.toArray()).toArray());
		springApplication.setWebEnvironment(true);
		springApplication.setAdditionalProfiles(env);
		springApplication.run(parameters.toArray(new String[0]));

		LOGGER.info(appName + " startup complete.");
		new DemoApp().startDemo();
		Thread.sleep(Long.MAX_VALUE);

	}

	@Bean
	public ApplicationListener<ApplicationExitEvent> applicationExitListener() {
		return new ApplicationListener<ApplicationExitEvent>() {

			@Override
			public void onApplicationEvent(ApplicationExitEvent event) {
				event.logReason(LOGGER);
				System.exit(event.getExitCode());
			}
		};
	}

}
