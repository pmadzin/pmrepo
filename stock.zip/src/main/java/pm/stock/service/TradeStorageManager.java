package pm.stock.service;

import java.util.Collection;

import pm.stock.domian.Trade;

public interface TradeStorageManager {
	
	void saveTrades(Collection<Trade> trades);
	
	Collection<Trade> getStoredTrades();
	

}
