package pm.stock.service;


import java.util.Collection;


import org.joda.time.LocalDateTime;

import pm.stock.domian.Trade;

/**
 * This is a service class to integrate with trade system.
 * @author pmadzin
 *
 */
public interface TradeConnectorService {
	
	
	// get all trade what booked after given time for given symbol
	Collection<Trade> getTradesAfter(String symbol,LocalDateTime time);

}
