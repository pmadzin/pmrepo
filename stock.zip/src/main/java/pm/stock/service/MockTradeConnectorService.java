package pm.stock.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import org.joda.time.LocalDateTime;
import org.springframework.stereotype.Service;

import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;

/**
 * This is mocking service to connect Trade system
 * 
 * @author pmadzin
 *
 */
@Service
public class MockTradeConnectorService implements TradeConnectorService {

	@Override
	public Collection<Trade> getTradesAfter(String symbol,LocalDateTime time) {
		// This will be a mock and generate few trades with random numbers
		Collection<Trade> trades = new ArrayList<Trade>();
		for (int i=0;i<10;i++) {
			BigDecimal price = new BigDecimal(randomWithRange(0.01, 100.00));
			Long quantity = new Long(randomWithRange(1l, 100l));
			trades.add(new Trade(symbol, TradeType.BUY, price, quantity));
			trades.add(new Trade(symbol, TradeType.SELL, new BigDecimal(randomWithRange(0.01, 100.00)),
					new Long(randomWithRange(1l, 100l))));
		}

		return trades;
	}

	private double randomWithRange(double min, double max) {
		double range = Math.abs(max - min);
		return (Math.random() * range) + (min <= max ? min : max);
	}

	private long randomWithRange(long min, long max) {
		long range = Math.abs(max - min) + 1;
		return (long) (Math.random() * range) + (min <= max ? min : max);
	}

}
