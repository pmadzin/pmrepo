package pm.stock.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Collection;

import org.springframework.stereotype.Service;

import pm.stock.domian.GBCEStock;
import pm.stock.domian.StockType;
import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;

@Service
public class CalculationServiceImpl implements CalculationService, Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final MathContext MCONTEX = new MathContext(5, RoundingMode.HALF_UP);


	@Override
	public BigDecimal calculateDividentYield(BigDecimal trickerPrice, GBCEStock stock) {
		BigDecimal result = null;
		// based on stock type use differnt formula
		if (StockType.COMMON.equals(stock.getStockType())) {
			result= new BigDecimal(stock.getLastDivident()).divide(trickerPrice,MCONTEX);
					
		} else if (StockType.PREFERRED.equals(stock.getStockType())) {
			// TODO confirm with business the meaning of . in the specification assume it's a percentage
			result = new BigDecimal(stock.getFixedDivident()).divide(new BigDecimal(100l)).multiply(new BigDecimal(stock.getPairValue())).divide(trickerPrice,MCONTEX);
		}
		return result;
	}

	@Override
	public BigDecimal calculatePERatio(BigDecimal trickerPrice, Long dividend) {
		if (dividend==0) {
			return null;
		}
		return new BigDecimal((trickerPrice.doubleValue() / dividend),MCONTEX);
	}

	@Override
	public BigDecimal calculateStockPrice(Collection<Trade> trades, int minutes, GBCEStock stock) {
		BigDecimal sumQantity = new BigDecimal(0l);
		BigDecimal summ = new BigDecimal(0l);
		summ.setScale(5);

		org.joda.time.LocalDateTime timeCheck = org.joda.time.LocalDateTime.now();
		timeCheck = timeCheck.minusMinutes(minutes);

		for (Trade trade : trades) {
			if (stock.getSymbol().equals(trade.getSymbol()) && trade.getTradeTime().isAfter(timeCheck)) {
				BigDecimal qnty = new BigDecimal(trade.getQuantity());
				summ = summ.add(trade.getPrice().multiply(qnty));
				sumQantity= sumQantity.add(qnty);
			}

		}
		if (sumQantity.longValue()<1) return null;
		return summ.divide(sumQantity, 5 ,RoundingMode.HALF_UP);
	
	}

	@Override
	public BigDecimal calculateGeometricMean(Collection<Trade> trades, TradeType tradeType, GBCEStock stock) {
		int counter = 0;
		BigDecimal summ = BigDecimal.ZERO;
		summ.setScale(5);

		for (Trade trade : trades) {
			if (stock.getSymbol().equals(trade.getSymbol()) && (TradeType.ALL.equals(tradeType) || tradeType.equals(trade.getTradeTime()))) {
				counter++;
				summ = summ.add(trade.getPrice(),MCONTEX);
			}
		}
		
		BigDecimal recCounter = BigDecimal.ONE.divide(new BigDecimal(counter),MCONTEX);

		BigDecimal value = new BigDecimal(Math.pow(summ.doubleValue(), recCounter.doubleValue()),MCONTEX);
		
		return value;

	}

}
