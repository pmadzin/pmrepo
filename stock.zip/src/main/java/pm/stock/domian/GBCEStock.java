package pm.stock.domian;

import java.io.Serializable;

/**
 * Input trade from GBCE trade
 * @author pmadzin
 *
 */
public class GBCEStock implements Serializable {

	private static final long serialVersionUID = -9139726238893790916L;
	
	private final String symbol;
	
	private final StockType stockType;
	
	private final Long pairValue;
	
	private final Long lastDivident;
	
	private final Long fixedDivident;
	

	public GBCEStock(String symbol, StockType stockType, Long pairValue, Long lastDivident, Long fixedDivident) {
		super();
		// ther is no validation on this data - maybe consider to add and throw exception if is called by invalid fields.
		this.symbol = symbol;
		this.stockType = stockType;
		this.pairValue = pairValue;
		this.lastDivident = lastDivident;
		this.fixedDivident = fixedDivident;
	}

	public String getSymbol() {
		return symbol;
	}

	public StockType getStockType() {
		return stockType;
	}

	public Long getPairValue() {
		return pairValue;
	}

	public Long getLastDivident() {
		return lastDivident;
	}

	public Long getFixedDivident() {
		return fixedDivident;
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.symbol;
	}
	
	
	

}
