package pm.stock.domian;

public enum StockType {
	COMMON("Common"), PREFERRED("Preferred "), ALL("Both");

	private final String displayName;

	StockType(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return this.displayName;
	}
}
