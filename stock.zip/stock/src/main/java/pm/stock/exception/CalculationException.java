package pm.stock.exception;

/**
 * All calculation related exceptions here as business exceptions
 * @author pmadzin
 *
 */
public class CalculationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1627464061619912793L;

	public CalculationException(String message) {
		super(message);		
	}
	
	

}
