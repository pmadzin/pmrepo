package pm.stock.domian;

public enum TradeType {

	BUY("B"), SELL("S"), ALL("Both");

	private final String displayName;

	TradeType(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return this.displayName;
	}
	
}
