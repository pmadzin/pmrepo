package pm.stock.domian;

import java.io.Serializable;
import java.math.BigDecimal;

import org.joda.time.LocalDateTime;


/**
 * record a trade, with timestamp, quantity of shares, buy or sell indicator and 
 * price
 */
 
public final class Trade implements Serializable {

	private static final long serialVersionUID = -2421344219106115914L;
	private final String symbol;
	private final LocalDateTime tradeTime;
	private final TradeType type;
	private final BigDecimal price;	
	private final Long quantity;
	
	public Trade(String symbol, LocalDateTime tradeTime, TradeType type, BigDecimal price, Long quantity) {
		super();
		// ther is no validation on this data - maybe consider to add and throw exception if is called by invalid fields.
		this.symbol = symbol;
		this.tradeTime = tradeTime;
		this.type = type;
		this.price = price;
		this.quantity = quantity;
	}
	
	public Trade(String symbol,TradeType type, BigDecimal price, Long quantity) {
		super();
		// ther is no validation on this data - maybe consider to add and throw exception if is called by invalid fields.
		this.symbol = symbol;
		this.tradeTime = LocalDateTime.now();
		this.type = type;
		this.price = price;
		this.quantity = quantity;
	}

	public LocalDateTime getTradeTime() {
		return tradeTime;
	}

	public TradeType getType() {
		return type;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public Long getQuantity() {
		return quantity;
	}
	
	public boolean isSell() {
		return TradeType.SELL.equals(this.type);
	}
	
	public boolean isBuy() {
		return TradeType.BUY.equals(this.type);
	}

	public String getSymbol() {
		return symbol;
	}
	
}
