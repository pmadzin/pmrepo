package pm.stock.config;

import java.math.BigDecimal;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pm.stock.domian.GBCEStock;
import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;
import pm.stock.exception.CalculationException;
import pm.stock.service.CalculationService;
import pm.stock.service.CalculationServiceImpl;
import pm.stock.service.MockStockConnectorService;
import pm.stock.service.MockTradeConnectorService;
import pm.stock.service.MockTradeStorageManager;
import pm.stock.service.StockConnectorService;
import pm.stock.service.TradeConnectorService;
import pm.stock.service.TradeStorageManager;

/**
 * This is a demo class to simulate real time works of the application. Can use
 * as basic example for future development (like performance test)
 * 
 * @author pmadzin
 *
 */
public class DemoApp {

	private static final Logger LOGGER = LoggerFactory.getLogger(DemoApp.class);

	MockTradeConnectorService tradeConnection = new MockTradeConnectorService();

	MockStockConnectorService stockConnectorService = new MockStockConnectorService();

	MockTradeStorageManager storageManager = new MockTradeStorageManager();

	CalculationServiceImpl calculationService = new CalculationServiceImpl();

	public void startDemo() {
		while (true) {
			LOGGER.info("........Start new demo sequence.....................");

			for (String symbol : stockConnectorService.getStockSymbols()) {
				Collection<Trade> trades = tradeConnection.getTradesAfter(symbol, org.joda.time.LocalDateTime.now());
				storageManager.saveTrades(trades);
			}
			long sTime = System.currentTimeMillis();

			for (GBCEStock stock : stockConnectorService.getStocks()) {
				try {
					BigDecimal stockPrice = calculationService.calculateStockPrice(storageManager.getStoredTrades(), 2,
							stock);
					LOGGER.info("Stock {} Price is {} - based on last 2 minutes trades", stock, stockPrice);
					if (stockPrice != null) {
						BigDecimal dyeld = calculationService.calculateDividentYield(stockPrice, stock);
						BigDecimal peoratio = calculationService.calculatePERatio(stockPrice, stock.getLastDivident());
						BigDecimal geo = calculationService.calculateGeometricMean(storageManager.getStoredTrades(),
								TradeType.ALL, stock);
						LOGGER.info("Stock {} - Dividend Yield ={} , PE Ratio = {}, Geometric Mean = {}", stock, dyeld,
								peoratio, geo);
					}
				} catch (CalculationException e) {
					LOGGER.error("Busuness exception catched ",e);
				}
			}
			LOGGER.info("------Demo calculation finished under {} ms---------", System.currentTimeMillis() - sTime);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				LOGGER.info("InterruptedException do nothing");
			}

		}
	}

	public TradeConnectorService getTradeConnection() {
		return tradeConnection;
	}

	public StockConnectorService getStockConnectorService() {
		return stockConnectorService;
	}

	public TradeStorageManager getStorageManager() {
		return storageManager;
	}

	public CalculationService getCalculationService() {
		return calculationService;
	}
}
