package pm.stock.config;

import org.slf4j.Logger;
import org.springframework.context.ApplicationEvent;

public abstract class ApplicationExitEvent extends ApplicationEvent {
    private static final long serialVersionUID = 1L;

    private int exitCode;

    public ApplicationExitEvent(Object reason, int exitCode) {
        super(reason);
        this.exitCode = exitCode;
    }

    public int getExitCode() {
        return exitCode;
    }

    public abstract void logReason(Logger log);
	

}
