package pm.stock.service;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Service;

import pm.stock.domian.Trade;

/**
 * This is a mock service - should be save to database and get data from there.
 *  * 
 * @author pmadzin
 *
 */
@Service
public class MockTradeStorageManager implements TradeStorageManager {
	
	Collection<Trade> storage = new ArrayList<>();

	@Override
	public void saveTrades(Collection<Trade> trades) {
		
		
		storage.addAll(trades);

	}

	@Override
	public Collection<Trade> getStoredTrades() {		
		return storage;
	}

}
