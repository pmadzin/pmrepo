package pm.stock.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.springframework.stereotype.Service;

import pm.stock.domian.GBCEStock;
import pm.stock.domian.StockType;

/**
 * This is a mock implementation of service for connect to stock app and get data
 * 
 * @author pmadzin
 *
 */
@Service
public class MockStockConnectorService implements StockConnectorService {
	
	public static String[] symbols = {"TEA","POP","ALE","GIN","JOE"};

	@Override
	public Collection<GBCEStock> getStocks() {
		Collection<GBCEStock> data = new ArrayList<>();

		data.add(new GBCEStock("TEA", StockType.COMMON, 100l , 0l, null));
		data.add(new GBCEStock("POP", StockType.COMMON, 100l , 8l, null));
		data.add(new GBCEStock("ALE", StockType.COMMON, 60l , 23l, null));
		data.add(new GBCEStock("GIN", StockType.PREFERRED, 100l , 8l, 2l));
		data.add(new GBCEStock("JOE", StockType.COMMON, 250l , 13l, null));
		
		return data;
	}

	@Override
	public Collection<String> getStockSymbols() {
		return Arrays.asList(symbols);		
	}

}
