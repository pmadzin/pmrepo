package pm.stock.service;

import java.math.BigDecimal;
import java.util.Collection;

import pm.stock.domian.GBCEStock;
import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;
import pm.stock.exception.CalculationException;

public interface CalculationService {	
	
	//calculate the dividend yield
	BigDecimal calculateDividentYield(BigDecimal trickerPrice, GBCEStock stock) throws CalculationException;
	
	//calculate the P/E Ratio
	BigDecimal calculatePERatio(BigDecimal trickerPrice, Long dividend) throws CalculationException ;
	
	// Calculate Stock Price based on trades recorded in past x minutes
	BigDecimal calculateStockPrice(Collection<Trade> trades, int minutes, GBCEStock stock) throws CalculationException;
	
	//Calculate geometric meaning
	BigDecimal calculateGeometricMean(Collection<Trade> trades, TradeType tradeType, GBCEStock stock) throws CalculationException;
	

}
