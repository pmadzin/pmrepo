package pm.stock.service;

import java.util.Collection;

import pm.stock.domian.GBCEStock;

/**
 * Stock service connection. 
 * @author pmadzin
 *
 */
public interface StockConnectorService {

	Collection<GBCEStock> getStocks();
	
	Collection<String> getStockSymbols();
}
