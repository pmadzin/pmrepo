/**
 * 
 */
package pm.stock.service;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import pm.stock.config.StockServerConfig;
import pm.stock.domian.GBCEStock;
import pm.stock.domian.StockType;
import pm.stock.domian.Trade;
import pm.stock.domian.TradeType;
import pm.stock.exception.CalculationException;

/**
 * 
 * Main test for service
 * @author pmadzin
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { StockServerConfig.class })
public class CalculationServiceImplTest {

	@Autowired
	private CalculationService calcService;

	private static Map<String, GBCEStock> stockMap = new HashMap<>(5);

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		stockMap.put("TEA", new GBCEStock("TEA", StockType.COMMON, 100l, 0l, null));
		stockMap.put("POP", new GBCEStock("POP", StockType.COMMON, 100l, 8l, null));
		stockMap.put("ALE", new GBCEStock("ALE", StockType.COMMON, 60l, 23l, null));
		stockMap.put("GIN", new GBCEStock("GIN", StockType.PREFERRED, 100l, 8l, 2l));
		stockMap.put("JOE", new GBCEStock("JOE", StockType.COMMON, 250l, 13l, null));

	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for
	 * {@link pm.stock.service.CalculationServiceImpl#calculateDividentYield(java.math.BigDecimal, pm.stock.domian.GBCEStock)}
	 * .
	 * 
	 * @throws CalculationException
	 */
	@Test
	public void testCalculateDividentYield() throws CalculationException {
		BigDecimal trickerPrice = new BigDecimal(10);
		BigDecimal expRes1 = new BigDecimal("0");
		BigDecimal expRes2 = new BigDecimal("0.8");
		BigDecimal expRes3 = new BigDecimal("2.3");
		BigDecimal expRes4 = new BigDecimal("0.20");
		BigDecimal expRes5 = new BigDecimal("1.3");
		BigDecimal res1 = calcService.calculateDividentYield(trickerPrice, stockMap.get("TEA"));
		BigDecimal res2 = calcService.calculateDividentYield(trickerPrice, stockMap.get("POP"));
		BigDecimal res3 = calcService.calculateDividentYield(trickerPrice, stockMap.get("ALE"));
		BigDecimal res4 = calcService.calculateDividentYield(trickerPrice, stockMap.get("GIN"));
		BigDecimal res5 = calcService.calculateDividentYield(trickerPrice, stockMap.get("JOE"));
		assertEquals(expRes1, res1);
		assertEquals(expRes2, res2);
		assertEquals(expRes3, res3);
		assertEquals(expRes4, res4);
		assertEquals(expRes5, res5);
		// consider to add more test value to make sure works with various
		// combinations.
	}

	@Test(expected = CalculationException.class)
	public void testCalculateDividentYieldNullParams() throws CalculationException {
		calcService.calculateDividentYield(null, stockMap.get("TEA"));
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculateDividentYieldNullParams2() throws CalculationException {
		calcService.calculateDividentYield(new BigDecimal(10), null);
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculateDividentYieldWrongType() throws CalculationException {
		calcService.calculateDividentYield(new BigDecimal(10), new GBCEStock("TEST", StockType.ALL, 0l, 0l, 0l));
		fail("Exception should occure before");
	}

	/**
	 * Test method for
	 * {@link pm.stock.service.CalculationServiceImpl#calculatePERatio(java.math.BigDecimal, java.lang.Long)}
	 * .
	 * 
	 * @throws CalculationException
	 */
	@Test
	public void testCalculatePERatio() throws CalculationException {
		assertEquals(new BigDecimal("2"), calcService.calculatePERatio(new BigDecimal(10), 5l));
		assertEquals(new BigDecimal("2"), calcService.calculatePERatio(new BigDecimal(10), -5l));
		// consider to add more to improve stability
		assertEquals(new BigDecimal("0"), calcService.calculatePERatio(new BigDecimal(10), 0l));
	}

	@Test(expected = CalculationException.class)
	public void testCalculatePERatioException() throws CalculationException {
		calcService.calculatePERatio(null, 0l);
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculatePERatioException2() throws CalculationException {
		calcService.calculatePERatio(new BigDecimal(10), null);
		fail("Exception should occure before");
	}

	/**
	 * Test method for
	 * {@link pm.stock.service.CalculationServiceImpl#calculateStockPrice(java.util.Collection, int, pm.stock.domian.GBCEStock)}
	 * .
	 * 
	 * @throws CalculationException
	 */
	@Test
	public void testCalculateStockPrice() throws CalculationException {
		BigDecimal res1 = calcService.calculateStockPrice(generateTrades("TEA"), 20, stockMap.get("TEA"));
		BigDecimal res2 = calcService.calculateStockPrice(generateTrades("POP"), 20, stockMap.get("POP"));
		BigDecimal res3 = calcService.calculateStockPrice(generateTrades("ALE"), 20, stockMap.get("ALE"));
		BigDecimal res4 = calcService.calculateStockPrice(generateTrades("GIN"), 20, stockMap.get("GIN"));
		BigDecimal res5 = calcService.calculateStockPrice(generateTrades("JOE"), 20, stockMap.get("JOE"));
		// Always same value expected !
		assertEquals(new BigDecimal("633.33333"), res1);
		assertTrue(res1.equals(res2));
		assertTrue(res1.equals(res3));
		assertTrue(res1.equals(res4));
		assertTrue(res1.equals(res5));
		// when no trade in the time frame
		BigDecimal res0 = calcService.calculateStockPrice(setTimeBack(generateTrades("TEA")), 20, stockMap.get("TEA"));
		assertEquals(new BigDecimal("0"), res0);
	}

	@Test(expected = CalculationException.class)
	public void testCalculateStockPriceException1() throws CalculationException {
		calcService.calculateStockPrice(Collections.EMPTY_LIST, 20, stockMap.get("TEA"));
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculateStockPriceException2() throws CalculationException {
		calcService.calculateStockPrice(generateTrades("TEA"), 20, null);
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculateStockPriceException3() throws CalculationException {
		calcService.calculateStockPrice(generateTrades("TEA"), 0, stockMap.get("TEA"));
		fail("Exception should occure before");
	}

	/**
	 * Test method for
	 * {@link pm.stock.service.CalculationServiceImpl#calculateGeometricMean(java.util.Collection, pm.stock.domian.TradeType, pm.stock.domian.GBCEStock)}
	 * .
	 * 
	 * @throws CalculationException
	 */
	@Test
	public void testCalculateGeometricMean() throws CalculationException {
		BigDecimal resBuy = calcService.calculateGeometricMean(generateTrades("TEA"), TradeType.BUY,
				stockMap.get("TEA"));
		BigDecimal resSell = calcService.calculateGeometricMean(generateTrades("TEA"), TradeType.SELL,
				stockMap.get("TEA"));
		BigDecimal resAll = calcService.calculateGeometricMean(generateTrades("TEA"), TradeType.ALL,
				stockMap.get("TEA"));

		assertEquals(new BigDecimal("2.5463"), resBuy);
		assertEquals(BigDecimal.ZERO, resSell);// no sell in the test
		assertEquals(resAll, resBuy);
	}

	@Test(expected = CalculationException.class)
	public void testCalculateGeometricMeanException1() throws CalculationException {
		calcService.calculateGeometricMean(Collections.EMPTY_LIST, TradeType.BUY, stockMap.get("TEA"));
		fail("Exception should occure before");
	}

	@Test(expected = CalculationException.class)
	public void testCalculateGeometricMeanException2() throws CalculationException {
		calcService.calculateGeometricMean(generateTrades("TEA"), TradeType.BUY, null);
		fail("Exception should occure before");
	}

	public CalculationService getCalcService() {
		return calcService;
	}

	public void setCalcService(CalculationService calcService) {
		this.calcService = calcService;
	}

	private Collection<Trade> setTimeBack(Collection<Trade> original) {
		LocalDateTime oldtime = LocalDateTime.now().minusDays(1);
		Collection<Trade> trades = new ArrayList<>();
		for (Trade t : original) {
			trades.add(new Trade(t.getSymbol(), oldtime, t.getType(), t.getPrice(), t.getQuantity()));
		}
		return trades;
	}

	private Collection<Trade> generateTrades(String symbol) {
		Collection<Trade> trades = new ArrayList<>();
		for (int i = 1; i < 10; i++) {
			BigDecimal price = new BigDecimal(100 * i);
			Long quantity = new Long(i * 2);
			trades.add(new Trade(symbol, TradeType.BUY, price, quantity));
		}
		return trades;
	}

}
